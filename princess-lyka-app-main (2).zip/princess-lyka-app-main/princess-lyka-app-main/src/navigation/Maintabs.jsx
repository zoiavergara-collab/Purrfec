import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import HomePage from "../components/Maintabs/HomePage/HomePage";
import Cart from "../components/Maintabs/Cart/Cart";
import UserProfile from "../components/Maintabs/UserProfile/UserProfile";
import Wishlist from "../components/Maintabs/Wishlist/Wishlist";

import CustomBottomBar from "../components/ui/CustomeBottomBar/CustomBottomBar";
import ChatbotScreen from "../screens/ChatBot/ChatbotScreen";

const Tab = createBottomTabNavigator();

export default function Maintabs() {
	return (
		<Tab.Navigator
			screenOptions={{ headerShown: false }}
			tabBar={(props) => <CustomBottomBar {...props} />}
		>
			<Tab.Screen name="HomePage" component={HomePage} />
			<Tab.Screen name="Wishlist" component={Wishlist} />
			<Tab.Screen name="Cart" component={Cart} />
			<Tab.Screen name="Profile" component={UserProfile} />
			<Tab.Screen name="ChatBot" component={ChatbotScreen} />
		</Tab.Navigator>
	);
}
