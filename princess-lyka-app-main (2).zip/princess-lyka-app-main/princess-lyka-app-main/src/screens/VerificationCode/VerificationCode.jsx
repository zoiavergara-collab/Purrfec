import { useNavigation, CommonActions } from "@react-navigation/native";
import { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import styles from "./styles";

const PAW_ICON = "🐾";

export default function VerificationCode() {
  const navigation = useNavigation();
  const [code, setCode] = useState(["", "", "", ""]);

  const input0 = useRef(null);
  const input1 = useRef(null);
  const input2 = useRef(null);
  const input3 = useRef(null);
  const inputs = [input0, input1, input2, input3];

  const handleChange = (text, index) => {
    const newCode = [...code];
    newCode[index] = text;
    setCode(newCode);
    if (text && index < 3) {
      inputs[index + 1].current.focus();
    }
  };

  const handleKeyPress = ({ nativeEvent }, index) => {
    if (nativeEvent.key === "Backspace" && !code[index] && index > 0) {
      inputs[index - 1].current.focus();
    }
  };

  const handleDone = () => {
    navigation.dispatch(CommonActions.navigate({ name: "Maintabs" }));
  };

  const handleResend = () => {
    setCode(["", "", "", ""]);
    inputs[0].current.focus();
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
      >
        <View style={styles.content}>
          <Text style={styles.title}>Verification Code</Text>
          <Text style={styles.subtitle}>
            Please type the verification code sent to{"\n"}youremail@gmail.com
          </Text>

          <View style={styles.otpRow}>
            {code.map((digit, index) => (
              <View key={index} style={styles.otpBox}>
                {!digit ? (
                  <Text style={styles.pawIcon}>{PAW_ICON}</Text>
                ) : null}
                <TextInput
                  ref={inputs[index]}
                  style={[styles.otpInput, digit ? styles.otpInputFilled : null]}
                  value={digit}
                  onChangeText={(text) => handleChange(text.slice(-1), index)}
                  onKeyPress={(e) => handleKeyPress(e, index)}
                  keyboardType="number-pad"
                  maxLength={1}
                  caretHidden={true}
                />
              </View>
            ))}
          </View>

          <TouchableOpacity
            style={styles.button}
            onPress={handleDone}
            activeOpacity={0.85}
          >
            <Text style={styles.buttonText}>DONE</Text>
          </TouchableOpacity>

          <View style={styles.resendRow}>
            <Text style={styles.resendText}>Didn't receive the code? </Text>
            <TouchableOpacity onPress={handleResend}>
              <Text style={styles.resendLink}>Resend</Text>
            </TouchableOpacity>
          </View>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}