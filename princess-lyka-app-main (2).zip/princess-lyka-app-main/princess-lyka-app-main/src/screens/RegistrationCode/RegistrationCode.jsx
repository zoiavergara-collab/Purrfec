import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  SafeAreaView,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import styles from './styles';

const RegistrationCode = ({ navigation }) => {
  const [phone, setPhone] = useState('');

  const handleSend = () => {
    navigation.navigate('HomeScreen');
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <KeyboardAvoidingView
        style={styles.container}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      >
        <View style={styles.content}>
          <Text style={styles.title}>Registration</Text>
          <Text style={styles.subtitle}>
            Enter your phone number to verify your account
          </Text>

          <View style={styles.inputContainer}>
            <Text style={styles.flag}>🇵🇭</Text>
            <Text style={styles.arrow}>▾</Text>
            <Text style={styles.countryCode}>+63</Text>
            <TextInput
              style={styles.input}
              placeholder="000 000 0000"
              placeholderTextColor="#aaa"
              value={phone}
              onChangeText={setPhone}
              keyboardType="phone-pad"
              maxLength={10}
            />
          </View>

          <TouchableOpacity
            style={styles.button}
            onPress={handleSend}
            activeOpacity={0.85}
          >
            <Text style={styles.buttonText}>SEND</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

export default RegistrationCode;