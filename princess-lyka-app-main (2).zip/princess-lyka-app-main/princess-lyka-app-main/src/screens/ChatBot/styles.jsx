import { StyleSheet } from "react-native";

export const styles = StyleSheet.create({
  safe: {
    flex: 1,
    backgroundColor: "#fff",
  },
  container: {
    flex: 1,
    paddingHorizontal: 16,
  },
  messageList: {
    paddingVertical: 16,
    gap: 12,
  },
  bubble: {
    flexDirection: "row",
    alignItems: "flex-start",
    padding: 14,
    borderRadius: 16,
    maxWidth: "90%",
  },
  botBubble: {
    backgroundColor: "#F5A623",
    alignSelf: "flex-start",
    borderTopLeftRadius: 4,
  },
  userBubble: {
    backgroundColor: "#F5A623",
    alignSelf: "flex-end",
    borderTopRightRadius: 4,
  },
  sparkle: {
    fontSize: 14,
    color: "#1a1a1a",
    marginRight: 4,
    marginTop: 1,
  },
  bubbleText: {
    fontSize: 14,
    color: "#1a1a1a",
    lineHeight: 20,
    flexShrink: 1,
  },
  inputRow: {
    flexDirection: "row",
    alignItems: "flex-end",
    paddingVertical: 12,
    gap: 10,
  },
  inputContainer: {
    flex: 1,
    flexDirection: "row",
    alignItems: "flex-end",
    backgroundColor: "#F5A623",
    borderRadius: 16,
    paddingHorizontal: 14,
    paddingVertical: 10,
    minHeight: 52,
  },
  input: {
    flex: 1,
    fontSize: 14,
    color: "#1a1a1a",
    maxHeight: 80,
  },
  micButton: {
    marginLeft: 8,
    justifyContent: "center",
    paddingBottom: 2,
  },
  micIcon: {
    fontSize: 18,
  },
  sendButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    backgroundColor: "#3a3a3a",
    justifyContent: "center",
    alignItems: "center",
  },
  sendIcon: {
    color: "#fff",
    fontSize: 18,
  },
});