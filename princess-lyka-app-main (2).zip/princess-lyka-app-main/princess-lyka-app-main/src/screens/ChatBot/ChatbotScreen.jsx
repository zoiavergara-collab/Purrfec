import { useState, useRef } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  KeyboardAvoidingView,
  Platform,
} from "react-native";
import { SafeAreaView, useSafeAreaInsets } from "react-native-safe-area-context";
import ScreenHeader from "../../components/ui/ScreenHeader/ScreenHeader";
import { styles } from "./styles";

const INITIAL_MESSAGES = [
  {
    id: "1",
    text: "Hi, you can ask me anything about Princess Kyla",
    sender: "bot",
  },
  {
    id: "2",
    text: "I suggest you some questions you can ask me..",
    sender: "bot",
  },
];

export default function ChatbotScreen() {
  const [messages, setMessages] = useState(INITIAL_MESSAGES);
  const [input, setInput] = useState("");
  const flatListRef = useRef(null);
  const insets = useSafeAreaInsets();

  const handleSend = () => {
    if (!input.trim()) return;

    const userMessage = {
      id: Date.now().toString(),
      text: input.trim(),
      sender: "user",
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");

    // Simulate bot response
    setTimeout(() => {
      const botMessage = {
        id: (Date.now() + 1).toString(),
        text: "Let me find that information for you!",
        sender: "bot",
      };
      setMessages((prev) => [...prev, botMessage]);
    }, 800);
  };

  const renderMessage = ({ item }) => {
    const isBot = item.sender === "bot";
    return (
      <View style={[styles.bubble, isBot ? styles.botBubble : styles.userBubble]}>
        {isBot && <Text style={styles.sparkle}>✦ </Text>}
        <Text style={styles.bubbleText}>{item.text}</Text>
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safe}>
      <ScreenHeader title="Purrfect AI" onBack={undefined} />
      <KeyboardAvoidingView
        style={[styles.container, { paddingBottom: insets.bottom + 150 }]}
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        keyboardVerticalOffset={90}
      >
        <FlatList
          ref={flatListRef}
          data={messages}
          keyExtractor={(item) => item.id}
          renderItem={renderMessage}
          contentContainerStyle={styles.messageList}
          onContentSizeChange={() =>
            flatListRef.current?.scrollToEnd({ animated: true })
          }
        />

        <View style={styles.inputRow}>
          <View style={styles.inputContainer}>
            <TextInput
              style={styles.input}
              value={input}
              onChangeText={setInput}
              placeholder="Best Dry Food For Cat&#10;Who's Suffering from UTI ..."
              placeholderTextColor="#b8860b"
              multiline
            />
          
          </View>
          <TouchableOpacity style={styles.sendButton} onPress={handleSend}>
            <Text style={styles.sendIcon}>➤</Text>
          </TouchableOpacity>
        </View>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
}